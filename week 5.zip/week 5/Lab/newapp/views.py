from django.http import JsonResponse

def hello(request):
    response_data = {"Message": "Hello World!"}
    return JsonResponse(response_data)
