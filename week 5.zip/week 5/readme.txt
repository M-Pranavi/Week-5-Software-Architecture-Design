1. Install python and Django on your system
2. open cmd in project directory Lab.
3. Type following command in cmd "python manage.py runserver"
4. Server is now running
5. Go to browser and type in address bar http://127.0.0.1:8000/hello/
5. A page will show with Hello word on Top left corner.
